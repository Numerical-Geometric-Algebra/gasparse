.. gasparse documentation master file, created by
   sphinx-quickstart on Sun Apr  7 10:57:23 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   README
   init_ga
   

==================
Indices and tables
==================


* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
